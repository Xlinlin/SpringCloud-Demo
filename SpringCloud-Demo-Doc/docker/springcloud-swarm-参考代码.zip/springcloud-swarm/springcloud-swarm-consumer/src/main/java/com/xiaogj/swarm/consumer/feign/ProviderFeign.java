package com.xiaogj.swarm.consumer.feign;

import com.xiaogj.swarm.consumer.feign.fallback.ProviderFallBack;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

//@FeignClient(name = "SWARM-PROVIDER", path = "/provider", fallback = ProviderFallBack.class)
@FeignClient(name = "SWARM-PROVIDER", path = "/provider")
public interface ProviderFeign {

    @RequestMapping("/hello")
    String hello();
}
