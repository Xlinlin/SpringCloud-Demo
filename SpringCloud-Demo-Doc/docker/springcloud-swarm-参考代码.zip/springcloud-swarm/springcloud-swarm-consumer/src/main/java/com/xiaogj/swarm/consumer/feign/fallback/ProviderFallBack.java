package com.xiaogj.swarm.consumer.feign.fallback;

import com.xiaogj.swarm.consumer.feign.ProviderFeign;
import org.springframework.stereotype.Component;

@Component
public class ProviderFallBack implements ProviderFeign {
    @Override
    public String hello() {
        return "Provider fall back!";
    }
}
