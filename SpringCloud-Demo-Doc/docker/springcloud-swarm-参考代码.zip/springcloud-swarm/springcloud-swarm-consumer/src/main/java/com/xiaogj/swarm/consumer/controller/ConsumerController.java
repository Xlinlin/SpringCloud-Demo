package com.xiaogj.swarm.consumer.controller;

import com.xiaogj.swarm.consumer.feign.ProviderFeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/consumer")
@RestController
public class ConsumerController {
    @Autowired
    private ProviderFeign providerFeign;

    @RequestMapping("/helloConsumer")
    public String helloConsumer() {
        return "Hello Swarm consumer!";
    }

    @RequestMapping("/helloProvider")
    public String helloProvider() {
        return providerFeign.hello();
    }
}
