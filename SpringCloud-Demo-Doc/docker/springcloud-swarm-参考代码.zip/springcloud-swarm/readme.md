**docker swarm 部署 springcloud**   
-

_前提已经安装好docker swarm集群_<br>
_在swarm主节点上创建了网络``docker network create --driver overlay springcloud-overlay``_<br>
_主要注意容器内网络，swarm集群内部可以通过services的name做dns使用_<br>


- 标准版的spring cloud项目包含4部分``eureka、gateway、provider、consumer``<br>
- 请求流程：``client请求-->gateway-->consumer(feign)-->provider``
- 在swarm manager节点上，执行``docker stack deploy -c XXXX.yml stack_name`` 部署上述四个服务

1. eureka-server配置
* application.yml配置：
```yaml
# 容器环境变量
docker:
  env:
    eureka:
      ## 通过容器指定参数
      host: ${EUREKA_HOST}
      port: ${EUREKA_PORT}
      hostname: ${INSTANCE_NAME:localhost}
eureka:
  instance:
    hostname: ${docker.env.eureka.hostname}
    instance-id: ${eureka.instance.hostname}:${server.port}
  client:
    fetch-registry: true
    register-with-eureka: true
    service-url:
      #defaultZone: http://localhost:8888/eureka
      defaultZone: http://${docker.env.eureka.host}:${docker.env.eureka.port}/eureka
  server:
    enable-self-preservation: false
```
* 对应EUREKA-HA相互注册的eureka的 stack脚本，springcloud-eureka-ha.yml:
```yaml
version: "3.4"

# eureka
services:
  swarm-eureka1:
    image: xdevp.xiaogj.com:8088/mall/springcloud-swarm-eureka
    deploy:
      replicas: 1
      restart_policy:
        condition: on-failure
    volumes:
      - /tmp:/tmp
    networks:
      springcloud-overlay:
        aliases:
          # 该网络内取一个别名，即DNS，只要在springcloud-overlay网络内就可以通过swarm-eureka:8888可以访问注册中心
          - swarm-eureka
    ports:
      # 对外暴露端口:容器内部端口
      - "9888:8888"
    environment:
      # 注册到swarm-eureka2的注册中心
      - EUREKA_HOST=swarm-eureka2
      # 相互注册，使用容器内的8888端口并非暴露的 9888端口
      - EUREKA_PORT=8888
      # 注册到eureka的实例 ID名称，取当前服务的名称：swarm-eureka1，内网通过服务名称做dns服务发现
      - INSTANCE_NAME=swarm-eureka1
  swarm-eureka2:
    image: xdevp.xiaogj.com:8088/mall/springcloud-swarm-eureka
    volumes:
      - /tmp:/tmp
    networks:
      springcloud-overlay:
        aliases:
          - swarm-eureka
    ports:
      - "9889:8888"
    environment:
      - EUREKA_HOST=swarm-eureka1
      - EUREKA_PORT=8888
      - INSTANCE_NAME=swarm-eureka2
# 需要先创建网络：docker network create --driver overlay springcloud-overlay
networks:
  springcloud-overlay:
    external: true
```
执行``docker stack deploy -c springcloud-eureka-ha.yml springcloud-eureka``

2. eureka client端配置，gateway、provider、consumer端的 eureka配置都一样
```yaml
# docker 环境变量设置
docker:
  env:
    eureka:
      host: ${EUREKA_HOST:localhost}
      port: ${EUREKA_PORT:8888}
      username: ${EUREKA_USERNAME}
      password: ${EUREKA_PASSWORD}
      hostname: ${INSTANCE_NAME:localhost}
      fetch: ${EUREKA_FETCH:true}
      register: ${EUREKA_REGISTER:true}
      # 版本号支持
      metadata:
        version: ${SERVICE_VERSION:v1}
eureka:
  client:
    register-with-eureka: ${docker.env.eureka.register}
    fetch-registry: ${docker.env.eureka.fetch}
    service-url:
      #defaultZone: http://localhost:8888/eureka
      ## 通过容器指定参数
      defaultZone: http://${docker.env.eureka.host}:${docker.env.eureka.port}/eureka
      #defaultZone: http://${docker.env.eureka.username}:${docker.env.eureka.password}@${docker.eureka.host}:${docker.eureka.port}/eureka
  instance:
    # 使用docker 编排里面的service name，即定义的service名称
    hostname: ${docker.env.eureka.hostname}
    ## 元数据
    metadata-map:
      version: ${docker.env.eureka.metadata.version}
      #weight: 10
    # 使用ip注册
    #prefer-ip-address: true
    #instance-id: ${spring.cloud.client.ip-address}:${server.port}
    instance-id: ${eureka.instance.hostname}:${server.port}
    ## 心跳和续约
    lease-expiration-duration-in-seconds: 60
    lease-renewal-interval-in-seconds: 10
```

3. 部署脚本springcloud-gateway.yml
```yaml
version: "3.4"

# gateway
services:
  springncloud-gateway:
    # 私服仓库拉取镜像，前提是集群内所有节点都需要先使用docker login登陆到私服
    image: xdevp.xiaogj.com:8088/mall/springcloud-swarm-gateway
    ports:
      - "9082:9082"
    networks:
      springcloud-overlay:
        aliases:
          - springncloud-gateway
    ## 内部eureka instance_id 使用SERVICE_NAME变量，变量的值为 service的名称，docker集群内部使用dns
    environment:
      # 使用注册中心定义的别名为注册中心的host
      - EUREKA_HOST=swarm-eureka
      - EUREKA_PORT=8888
      #  划重点：使用service name定义的名称作为instance_id，同集群网络内通过service name做dns相互调用
      - INSTANCE_NAME=springncloud-gateway
    # 该部分仅 stack deploy的时候有效
    deploy:
      replicas: 1
      # 重启策略
      restart_policy:
        condition: on-failure
      # 资源限制
      resources:
        limits:
          cpus: '1'
          memory: 1024M
        reservations:
          cpus: '0.2'
          memory: 150M
    volumes:
      - /tmp:/tmp

# 需要先创建网络：docker network create --driver overlay springcloud-overlay
networks:
  springcloud-overlay:
    external: true
```
执行``docker stack deploy -c springcloud-gateway.yml springcloud-gateway``

4. provider和consumer的stack 部署脚本springcloud-service.yml
```yaml
version: "3.4"

# springcloud service
services:
  springcloud-consumer:
    image: xdevp.xiaogj.com:8088/mall/springcloud-swarm-consumer
    ports:
      - "8087:8087"
    networks:
      springcloud-overlay:
        aliases:
          - springcloud-consumer
    ## 内部eureka instance_id 使用SERVICE_NAME变量，变量的值为 service的名称，docker集群内部使用dns
    environment:
      - EUREKA_HOST=swarm-eureka
      - EUREKA_PORT=8888
      - INSTANCE_NAME=springcloud-consumer
    deploy:
      replicas: 1
      restart_policy:
        condition: on-failure
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
        reservations:
          cpus: '0.2'
          memory: 200M
    volumes:
      - /tmp:/tmp

  springcloud-privoder:
    image: xdevp.xiaogj.com:8088/mall/springcloud-swarm-provider
    ports:
      - "8880:8880"
    networks:
      springcloud-overlay:
        aliases:
          - springcloud-privoder
    ## 内部eureka instance_id 使用SERVICE_NAME变量，变量的值为 service的名称，docker集群内部使用dns，
    # eureka端口使用容器内的8888端口非开放的端口
    environment:
      - EUREKA_HOST=swarm-eureka
      - EUREKA_PORT=8888
      - INSTANCE_NAME=springcloud-privoder
    deploy:
      replicas: 1
      restart_policy:
        condition: on-failure
      resources:
        limits:
          cpus: '1'
          memory: 512M
        reservations:
          cpus: '0.2'
          memory: 200M
    volumes:
      - /tmp:/tmp
networks:
  springcloud-overlay:
    external:
      name: springcloud-overlay
```
执行``docker stack deploy -c springcloud-service.yml springcloud-service``
