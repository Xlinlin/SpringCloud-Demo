/*
 * Winner 
 * 文件名  :HotDictReloadThread.java
 * 创建人  :llxiao
 * 创建时间:2018年2月8日
*/

package org.wltea.analyzer.dic.custome;

import org.apache.logging.log4j.Logger;
import org.elasticsearch.common.logging.ESLoggerFactory;

/**
 * [简要描述]:检测线程<br/>
 * [详细描述]:周期性的检测Redis订阅线程是否挂，如果挂了重新订阅<br/>
 *
 * @author llxiao
 * @version 1.0, 2018年2月8日
 */
public class HotDictReloadThread implements Runnable
{
    private static final Logger logger = ESLoggerFactory.getLogger(HotDictReloadThread.class.getName());

    @Override
    public void run()
    {
        logger.info("[------------------]Reload hot dict from mysql and redis!");
        // Dictionary.getSingleton().loadMySQLExtDict();
    }
}
