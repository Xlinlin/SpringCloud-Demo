/*
 * Winner 
 * 文件名  :RedisMsgPubSubListener.java
 * 创建人  :llxiao
 * 创建时间:2018年3月6日
*/

package org.wltea.analyzer.dic.custome;

import org.apache.logging.log4j.Logger;
import org.elasticsearch.common.logging.ESLoggerFactory;
import org.wltea.analyzer.dic.Dictionary;

import redis.clients.jedis.JedisPubSub;

/**
 * [简要描述]:redis发布订阅<br/>
 * [详细描述]:<br/>
 *
 * @author llxiao
 * @version 1.0, 2018年3月6日
 */
public class RedisSubscribeListener extends JedisPubSub
{
    private static final Logger logger = ESLoggerFactory.getLogger(RedisSubscribeListener.class.getName());

    /**
     * [简要描述]:消息到达<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @param channel
     * @param message
     * @see redis.clients.jedis.JedisPubSub#onMessage(java.lang.String, java.lang.String)
     */
    @Override
    public void onMessage(String channel, String message)
    {
        logger.info("[------------------]On message starting reload data!" + message);
        Dictionary.getSingleton().loadMySQLExtDict();
        super.onMessage(channel, message);
    }

    @Override
    public void onSubscribe(String channel, int subscribedChannels)
    {
        logger.warn("[------------------]On Subscribe success!" + channel);
        super.onSubscribe(channel, subscribedChannels);
    }

    @Override
    public void onUnsubscribe(String channel, int subscribedChannels)
    {
        logger.warn("[------------------]On UnSubscribe success!" + channel);
        super.onUnsubscribe(channel, subscribedChannels);
    }
}
