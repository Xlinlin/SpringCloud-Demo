/*
 * Winner 
 * 文件名  :MyThreadFactory.java
 * 创建人  :llxiao
 * 创建时间:2018年3月6日
*/

package org.wltea.analyzer.dic.custome;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.concurrent.ThreadFactory;

import org.apache.logging.log4j.Logger;
import org.elasticsearch.common.logging.ESLoggerFactory;
import org.wltea.analyzer.dic.Dictionary;

/**
 * [简要描述]:自定义线程<br/>
 * [详细描述]:设置线程名称，设置线程异常监控<br/>
 *
 * @author llxiao
 * @version 1.0, 2018年3月6日
 */
public class RedisSubscribeThreadFactory implements ThreadFactory
{

    private static final Logger logger = ESLoggerFactory.getLogger(RedisSubscribeThreadFactory.class.getName());

    private static int threadNum = 0;

    @Override
    public Thread newThread(Runnable arg0)
    {
        Thread t = new Thread(arg0, "Subscribe-Redis-Thread-" + threadNum);
        t.setUncaughtExceptionHandler(new UncaughtExceptionHandler()
        {
            @Override
            public void uncaughtException(Thread t, Throwable e)
            {
                Dictionary.reload.set(true);
                logger.error(Thread.currentThread().getName() + " stop!", e);
            }
        });
        threadNum++;
        return t;
    }

}
