/*
 * Winner 
 * 文件名  :SubscribeThread.java
 * 创建人  :llxiao
 * 创建时间:2018年3月6日
*/

package org.wltea.analyzer.dic.custome;

/**
 * [简要描述]:监听线程<br/>
 * [详细描述]:<br/>
 *
 * @author llxiao
 * @version 1.0, 2018年3月6日
 */
public class RedisSubscribeThread implements Runnable
{
    private RedisSever redisServer;
    private String channels;

    /**
     * [简要描述]:<br/>
     * [详细描述]:<br/>
     *
     * @author llxiao
     * @param redisServer
     * @param channels
     */
    public RedisSubscribeThread(RedisSever redisServer, String channels)
    {
        super();
        this.redisServer = redisServer;
        this.channels = channels;
    }

    @Override
    public void run()
    {
        redisServer.getJedis().subscribe(new RedisSubscribeListener(), channels);
    }
}
