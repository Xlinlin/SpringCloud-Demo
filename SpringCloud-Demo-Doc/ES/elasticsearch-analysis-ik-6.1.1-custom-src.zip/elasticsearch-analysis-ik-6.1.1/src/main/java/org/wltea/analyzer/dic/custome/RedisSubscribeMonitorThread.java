/*
 * Winner 
 * 文件名  :RedisSubscribeMonitorThread.java
 * 创建人  :llxiao
 * 创建时间:2018年3月6日
*/

package org.wltea.analyzer.dic.custome;

import java.util.concurrent.ExecutorService;

import org.apache.logging.log4j.Logger;
import org.elasticsearch.common.logging.ESLoggerFactory;
import org.wltea.analyzer.dic.Dictionary;

/**
 * [简要描述]:订阅线程监控<br/>
 * [详细描述]:<br/>
 *
 * @author llxiao
 * @version 1.0, 2018年3月6日
 */
public class RedisSubscribeMonitorThread implements Runnable
{
    private static final Logger logger = ESLoggerFactory.getLogger(RedisSubscribeMonitorThread.class.getName());

    private ExecutorService exutorService;
    private RedisSever redisServer;
    private String channels;

    /**
     * [简要描述]:<br/>
     * [详细描述]:<br/>
     *
     * @author llxiao
     * @param exutorService
     * @param redisServer
     * @param channels
     */
    public RedisSubscribeMonitorThread(ExecutorService exutorService, RedisSever redisServer, String channels)
    {
        super();
        this.exutorService = exutorService;
        this.redisServer = redisServer;
        this.channels = channels;
    }

    @Override
    public void run()
    {
        if (Dictionary.reload.get())
        {
            logger.error("[------------------]Redis subscribe thread stop,reset subscribe thread!");
            exutorService.execute(new RedisSubscribeThread(redisServer, channels));
        }
    }

}
