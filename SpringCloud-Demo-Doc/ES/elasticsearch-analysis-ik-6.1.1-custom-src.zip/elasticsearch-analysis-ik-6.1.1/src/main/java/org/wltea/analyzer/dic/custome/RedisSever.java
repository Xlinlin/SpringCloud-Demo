/*
 * Winner 
 * 文件名  :RedisSever.java
 * 创建人  :llxiao
 * 创建时间:2018年2月8日
*/

package org.wltea.analyzer.dic.custome;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.apache.logging.log4j.Logger;
import org.elasticsearch.common.logging.ESLoggerFactory;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisSentinelPool;
import redis.clients.jedis.exceptions.JedisConnectionException;
import redis.clients.jedis.exceptions.JedisDataException;

/**
 * [简要描述]:缓存服务<br/>
 * [详细描述]:<br/>
 *
 * @author llxiao
 * @version 1.0, 2018年2月8日
 * @since 项目名称 项目版本
 */
public class RedisSever
{
    private static final Logger logger = ESLoggerFactory.getLogger(RedisSever.class.getName());

    private final static int batchSize = 20;

    private int maxTotal = 50;
    private int maxWaitMillis = 1000;
    private int maxIdle = 5;
    private int minIdle = 2;
    private int timeOut = 5000;
    // 数据源连接池
    private static JedisSentinelPool pool;

    /**
     * 缓存中热词key
     */
    private String hotWordsKey;

    /**
     * 停止词缓存key
     */
    private String stopWordsKey;

    /**
     * [简要描述]:构造函数<br/>
     * [详细描述]:<br/>
     *
     * @author llxiao
     */
    public RedisSever(Properties prop)
    {
        init(prop);
    }

    /**
     * 初始化连接参数
     */
    private void init(Properties prop)
    {
        if (null == pool)
        {
            try
            {
                // IK 分词维护 缓存KEY
                hotWordsKey = prop.getProperty("redis.es.ik.hotwords.key", "esIKHotWords");
                stopWordsKey = prop.getProperty("redis.es.ik.stopwords.key", "esIKStopWords");

                String masterName = prop.getProperty("redis.master.name");
                String sentinelHostStr = prop.getProperty("redis.sentinels");
                String[] sentinelHosts = sentinelHostStr.split(",");
                if (logger.isInfoEnabled())
                {
                    logger.info("-------------------Start connection redis!");
                    logger.info("-------------------Redis connection info:");
                    logger.info("-------------------Hosts:" + sentinelHosts);
                    logger.info("-------------------Master name:" + masterName);
                    logger.info("-------------------Redis key:" + hotWordsKey);
                }
                Set<String> sentinels = new HashSet<String>(Arrays.asList(sentinelHosts));
                GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
                // 最大连接数
                poolConfig.setMaxTotal(maxTotal);
                poolConfig.setMaxWaitMillis(maxWaitMillis);
                // poolConfig.setTestOnBorrow(true);
                // 最大空闲连接数
                poolConfig.setMaxIdle(maxIdle);
                poolConfig.setMinIdle(minIdle);
                // 在空闲时检查有效性, 默认false
                poolConfig.setTestWhileIdle(false);
                // 连接耗尽时是否阻塞, false报异常,ture阻塞直到超时, 默认true
                poolConfig.setBlockWhenExhausted(true);
                // 获取连接时的最大等待毫秒数(如果设置为阻塞时BlockWhenExhausted),如果超时就抛异常, 小于零:阻塞不确定的时间,
                // 默认-1
                // poolConfig.setMaxWaitMillis(-1);
                // 逐出连接的最小空闲时间 默认1800000毫秒(30分钟)
                poolConfig.setMinEvictableIdleTimeMillis(90000);
                // 逐出扫描的时间间隔(毫秒) 如果为负数,则不运行逐出线程, 默认-1
                poolConfig.setTimeBetweenEvictionRunsMillis(60000);
                // 对象空闲多久后逐出, 当空闲时间>该值 且 空闲连接>最大空闲数
                // 时直接逐出,不再根据MinEvictableIdleTimeMillis判断 (默认逐出策略)
                // poolConfig.setSoftMinEvictableIdleTimeMillis(1800000);
                // 读取超时时间
                pool = new JedisSentinelPool(masterName, sentinels, poolConfig, timeOut);
                logger.info("------------------Connection redis success!");
            }
            catch (Exception e)
            {
                logger.error("redis客服端连接初始化异常," + e.getMessage(), e);
            }
        }
    }

    /**
     * [简要描述]:缓存中获取所有热词<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @return
     */
    public Set<String> getAllHotWords()
    {
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Query ik hot words from Redis!");
        }
        Set<String> hotWords = getForRedis(hotWordsKey);
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Query ik hot words from redis and Result:" + hotWords);
        }
        return hotWords;
    }

    /**
     * [简要描述]:缓存获取所有停止词<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @return
     */
    public Set<String> getAllStopWords()
    {
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Query ik stop words from Redis!");
        }
        Set<String> stopWords = this.getForRedis(stopWordsKey);
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Query ik stop words from redis and Result:" + stopWords);
        }
        return stopWords;
    }

    /**
     * [简要描述]:设置热词集到缓存中<br/>
     * [详细描述]:<br/>
     * 
     * @param hotWords
     *            热词集合
     * @author llxiao
     */
    public void setAllWords(Set<String> hotWords)
    {
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Set ik hot words to Redis!");
        }
        setData2Redis(this.hotWordsKey, hotWords);
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Set ik hot words to Redis successfully!");
        }
    }

    /**
     * [简要描述]:设置停止词到缓存<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @param stopWords
     */
    public void setAllTopWords(Set<String> stopWords)
    {
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Set ik stop words to Redis!");
        }
        setData2Redis(this.hotWordsKey, stopWords);
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Set ik stop words to Redis successfully!");
        }
    }

    /**
     * [简要描述]:设置数据到缓存<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @param key
     * @param hotWords
     */
    private void setData2Redis(String key, Set<String> hotWords)
    {
        if (null != hotWords && !hotWords.isEmpty())
        {

            Jedis jedis = null;
            boolean broken = false;
            try
            {
                jedis = this.getJedis();

                singleSet(key, hotWords, jedis);
                // batchSet(hotWords, jedis);
            }
            catch (Exception e)
            {
                broken = handleJedisException(e);
            }
            finally
            {
                closeResource(jedis, broken);
            }
        }

    }

    /**
     * [简要描述]:缓存获取指定的值<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @param key
     * @return
     */
    private Set<String> getForRedis(String key)
    {
        Jedis jedis = null;
        boolean broken = false;
        Set<String> hotWords = new HashSet<String>();
        try
        {
            jedis = getJedis();
            if (null != jedis)
            {
                hotWords = jedis.smembers(key);
            }
        }
        catch (Exception e)
        {
            broken = handleJedisException(e);
        }
        finally
        {
            closeResource(jedis, broken);
        }
        return hotWords;
    }

    /**
     * [简要描述]:单个设置<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @param key
     * @param hotWords
     * @param jedis
     */
    private void singleSet(String key, Set<String> hotWords, Jedis jedis)
    {
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Set ik hot words to Redis size:" + hotWords.size());
        }
        for (String string : hotWords)
        {
            jedis.sadd(key, string);
        }
    }

    /**
     * [简要描述]:批量设置<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @param hotWords
     * @param jedis
     */
    @SuppressWarnings("unused")
    private void batchSet(Set<String> hotWords, Jedis jedis)
    {
        String[] words = hotWords.toArray(new String[0]);
        int wordsSize = words.length;
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Set ik hot words to Redis size:" + wordsSize);
        }
        if (wordsSize >= batchSize)
        {
            // 批量添加到集合中 默认20个
            int remainder = wordsSize % batchSize;
            int copySize = wordsSize / batchSize;
            if (remainder != 0)
            {
                copySize = copySize + 1;
            }
            int index = 0;
            String[] destArray = null;
            int step = 0;
            for (int i = 0; i < copySize; i++)
            {
                step++;
                if (remainder != 0 && step == copySize)
                {
                    destArray = new String[remainder];
                }
                else
                {
                    destArray = new String[batchSize];
                }
                System.arraycopy(words, index, destArray, 0, destArray.length);
                index = index * copySize;
                if (logger.isDebugEnabled())
                {
                    logger.debug("------------------Batch set ik hot words to Redis size:" + destArray.length);
                    logger.debug("------------------Batch set ik hot words to Redis : " + destArray);
                }
                jedis.sadd(hotWordsKey, destArray);
            }
        }
        else
        {
            if (logger.isDebugEnabled())
            {
                logger.debug("------------------Set ik hot words to Redis size:" + words.length);
            }
            jedis.sadd(hotWordsKey, words);
        }
    }

    /**
     * 判断jedis抛出的异常类型，网络异常或者一般异常
     * 
     * @param exception
     * @return
     */
    private boolean handleJedisException(Exception exception)
    {
        // 无实际使用了，因为资源回收已经不需要判断异常 --caohong
        if (exception instanceof JedisConnectionException)
        {
            logger.error("Redis connection lost. Exception is : ", exception);
        }
        else if (exception instanceof JedisDataException)
        {
            if (exception.getMessage() != null && exception.getMessage().indexOf("READONLY") != -1)
            {
                logger.error("Redis connection are read-only slave. Exception is : ", exception);
            }
            else
            {
                return false;
            }
        }
        else
        {
            logger.error("Jedis exception happen. Exception is : ", exception);
        }
        return true;
    }

    /**
     * 关闭/是否连接池资源，若是网络异常，则断开连接，如果是一般异常，将直接抛出异常
     * 
     * @param jedis
     * @param conectionBroken
     */
    public void closeResource(Jedis jedis, boolean conectionBroken)
    {
        try
        {
            // 直接调用close方法，新客户端方法里面已经实现连接池回收处理逻辑 --caohong
            if (null != jedis && null != pool)
            {
                jedis.close();
            }
        }
        catch (Exception e)
        {
            logger.error("return back jedis failed, will force close the jedis," + e.getMessage(), e);
        }
    }

    /**
     * 获取不到redis连接返回Null
     * 
     * @return
     */
    public Jedis getJedis()
    {
        Jedis jedis = null;
        if (null != pool)
        {
            jedis = pool.getResource();
        }
        return jedis;
    }

}
