/*
 * Winner 
 * 文件名  :ConnectionManager.java
 * 创建人  :llxiao
 * 创建时间:2018年2月8日
*/

package org.wltea.analyzer.dic.custome;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.apache.logging.log4j.Logger;
import org.elasticsearch.common.logging.ESLoggerFactory;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.util.StringUtils;

/**
 * [简要描述]:<br/>
 * [详细描述]:<br/>
 *
 * @author llxiao
 * @version 1.0, 2018年2月8日
 * @since 项目名称 项目版本
 */
public class DBServer
{
    private static final Logger logger = ESLoggerFactory.getLogger(DBServer.class);

    private static DruidDataSource dataSource;
    private Properties prop;
    private String queryWordsSql;
    private String stopWordsSql;

    public DBServer(Properties prop)
    {
        this.prop = prop;
        initDataSource();
    }

    /**
     * [简要描述]:数据加载所有热词<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @return
     */
    public Set<String> getHotWords()
    {
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Starting query ik hot words for db!");
        }
        Set<String> words = new HashSet<String>();
        if (null != dataSource && !StringUtils.isEmpty(queryWordsSql))
        {
            Connection connection = null;
            Statement stmt = null;
            ResultSet rs = null;
            try
            {
                connection = dataSource.getConnection();
                stmt = connection.createStatement();
                logger.info("------------------Exucre query:" + queryWordsSql);
                rs = stmt.executeQuery(queryWordsSql);
                String theWord = "";
                while (rs.next())
                {
                    theWord = rs.getString("words");
                    if (!StringUtils.isEmpty(theWord))
                    {
                        words.add(theWord);
                    }
                }
            }
            catch (SQLException e)
            {
                logger.error("------------------Query ik hot words error for DB!", e);
            }
            finally
            {
                closeConnection(connection, stmt, rs);
            }
            if (logger.isDebugEnabled())
            {
                logger.debug("------------------Query ik hot words result:" + words);
            }
        }
        else
        {
            logger.info("------------------Can't load words from db!");
            logger.info("------------------Data Soruce is null:" + (null == dataSource));
            logger.info("------------------Query sql :" + queryWordsSql);
        }

        return words;
    }

    /**
     * [简要描述]:数据库加载停止词<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @return
     */
    public Set<String> getStopWords()
    {
        if (logger.isDebugEnabled())
        {
            logger.debug("------------------Starting query ik hot words for db!");
        }
        Set<String> stopWords = new HashSet<String>();
        if (null != dataSource && !StringUtils.isEmpty(queryWordsSql))
        {
            Connection connection = null;
            Statement stmt = null;
            ResultSet rs = null;
            try
            {
                connection = dataSource.getConnection();
                stmt = connection.createStatement();
                logger.info("------------------Exucre query:" + queryWordsSql);
                rs = stmt.executeQuery(stopWordsSql);
                String theWord = "";
                while (rs.next())
                {
                    theWord = rs.getString("stopwords");
                    if (!StringUtils.isEmpty(theWord))
                    {
                        stopWords.add(theWord);
                    }
                }
            }
            catch (SQLException e)
            {
                logger.error("------------------Query ik stop words error for DB!", e);
            }
            finally
            {
                closeConnection(connection, stmt, rs);
            }
            if (logger.isDebugEnabled())
            {
                logger.debug("------------------Query ik stop words result:" + stopWords);
            }
        }
        else
        {
            logger.info("------------------Can't load stop words from db!");
            logger.info("------------------Data Soruce is null:" + (null == dataSource));
            logger.info("------------------Query sql :" + queryWordsSql);
        }
        return stopWords;
    }

    /**
     * [简要描述]:关闭数据库相关连接<br/>
     * [详细描述]:<br/>
     * 
     * @author llxiao
     * @param connection
     *            Connection
     * @param stmt
     *            Statement
     * @param rs
     *            ResultSet
     */
    private void closeConnection(Connection connection, Statement stmt, ResultSet rs)
    {
        if (rs != null)
        {
            try
            {
                rs.close();
            }
            catch (SQLException e)
            {
                logger.error("error", e);
            }
        }
        if (stmt != null)
        {
            try
            {
                stmt.close();
            }
            catch (SQLException e)
            {
                logger.error("error", e);
            }
        }
        if (connection != null)
        {
            try
            {
                connection.close();
            }
            catch (SQLException e)
            {
                logger.error("error", e);
            }
        }
    }

    private void initDataSource()
    {
        if (null == dataSource)
        {
            String driverClass = prop.getProperty("jdbc.driver");
            if (StringUtils.isEmpty(driverClass))
            {
                driverClass = "com.mysql.jdbc.Driver";
            }
            String userName = prop.getProperty("jdbc.user");
            String password = prop.getProperty("jdbc.password");
            String jdbcUrl = prop.getProperty("jdbc.url");
            queryWordsSql = prop.getProperty("jdbc.ik.hotwords.sql");
            stopWordsSql = prop.getProperty("jdbc.reload.stopword.sql");
            if (logger.isInfoEnabled())
            {
                logger.info("------------------Starting connection db and db address:" + jdbcUrl);
                logger.info("------------------Query words sql:" + jdbcUrl);
            }
            dataSource = new DruidDataSource();
            dataSource.setDriverClassName(driverClass);
            dataSource.setUsername(userName);
            dataSource.setPassword(password);
            dataSource.setUrl(jdbcUrl);
            dataSource.setInitialSize(2);
            dataSource.setMinIdle(1);
            dataSource.setMaxActive(5);
            if (logger.isInfoEnabled())
            {
                logger.info("------------------Connection db success!");
            }
        }

    }

}
